# Magnolia Maids — Social Templates

Eight ready-to-post graphics in the Magnolia Maids brand system.
Typography: **Italiana** (display / wordmark), **Instrument Sans** (labels, prices, CTAs),
**Crimson Pro Italic** (accent line). Palette: ivory #FCFAF4, forest #0C2B19,
laurel #224D2F, brass #C49E57.

## Feed posts — 1080 x 1080 (Instagram, Facebook)

| File | Use | Caption starter |
|---|---|---|
| post-01-grand-opening | Launch announcement | Durant, we open September 1, 2026 at 8:00 AM. Founding rates for our first neighbors — book your first clean at magnoliamaids.pro. |
| post-02-founding-rates | Pricing transparency | Flat, honest pricing. Standard $129 · Bright $179 · Deep $249, plus up to 15% off recurring visits. No walkthroughs, no surprise fees. |
| post-03-airbnb-turnover | Short-term rental hosts | Hosting on Lake Texoma? Same-day turnovers from $119 — linens, restock, staging photos and a supply report after every guest. |
| post-04-now-hiring | Recruiting | We're hiring in Durant. $18–$26/hour, 100% of tips, paid training. Apply in 60 seconds at magnoliamaids.pro/about/careers. |
| post-05-instant-quote | Conversion / retarget | Know your price before we knock. Four questions, one flat total, under a minute. |

## Stories — 1080 x 1920 (Instagram/Facebook Stories, Reels covers)

| File | Use |
|---|---|
| story-01-grand-opening | Countdown to September 1, 2026 — pair with a countdown sticker |
| story-02-instant-quote | Price menu + quote CTA — add a link sticker to /booking |
| story-03-now-hiring | Recruiting story — link sticker to /about/careers |

## Posting notes

- Keep link stickers and profile chrome clear of the top and bottom 250px on stories; all copy sits inside that safe zone.
- Suggested hashtags: #DurantOK #BryanCountyOK #LakeTexoma #HouseCleaning #MagnoliaMaids
- Always pair a post with one CTA only: book, quote, or apply.
- Contact block on every asset: magnoliamaids.pro · (580) 745-0045 · Durant, OK
