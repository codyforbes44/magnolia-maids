# Magnolia Maids — Meta Ad Creatives & Copy
North Dallas, TX · magnoliamaids.pro · (214) 978-6445 · hello@magnoliamaids.pro

Three campaigns, two creative concepts each, two placements each (1:1 feed, 4:5 feed/mobile).
Every price traces to the site's canonical pricing. Referral credit = $25/$25 (confirm before running).

## Naming + tracking convention

Files: `{campaign}-{concept}-{ratio}.png`
- Concept A `photo` — dark photographic, editorial serif, brass offer bar. Best cold-audience stopper.
- Concept B `editorial` — ivory card with priced rows. Best retargeting / offer clarity.

Ad set naming in Ads Manager (keeps reporting joinable with GA4):
`MM | {campaign} | {concept} | {ratio} | {audience}`
Example: `MM | summer | photo | 4x5 | lookalike-1pct`

### UTM template (paste into "Website URL" URL parameters)

```
utm_source=facebook&utm_medium=paid_social&utm_campaign={{campaign}}&utm_content={{concept}}-{{ratio}}&utm_term={{adset.name}}&fbclid={{fbclid}}
```

Ready-made destination URLs:

| Campaign | Destination |
|---|---|
| Summer on the Lake | `https://magnoliamaids.pro/summer-on-the-lake?utm_source=facebook&utm_medium=paid_social&utm_campaign=summer_on_the_lake&utm_content=CONCEPT-RATIO` |
| Referral Week | `https://magnoliamaids.pro/referral-week?utm_source=facebook&utm_medium=paid_social&utm_campaign=referral_week&utm_content=CONCEPT-RATIO` |
| Holiday Ready | `https://magnoliamaids.pro/holiday-ready?utm_source=facebook&utm_medium=paid_social&utm_campaign=holiday_ready&utm_content=CONCEPT-RATIO` |

Replace `CONCEPT-RATIO` with `photo-1x1`, `photo-4x5`, `editorial-1x1`, or `editorial-4x5`.
Standard events to expect on the landing pages: `PageView` → `Lead` (campaign form submit). Set `Lead` as the optimization event once you clear ~20/week; before that, optimize for Landing Page Views.

---

## 1. Summer on the Lake — `summer-a-photo`, `summer-b-editorial`
**Objective:** Leads · **Audience:** North Dallas property owners, Airbnb/VRBO hosts, 25mi around Kingston/Cartwright/North Dallas · **Run:** May–August

### Primary text — A (host pain)
Back-to-back guests on North Dallas? We turn your rental between stays — linens stripped and remade, kitchen reset, bathrooms sanitized, amenities restocked, and staging photos in your inbox before we lock up.

Turnovers from $119. Same-day windows. Kingston, Cartwright, Platter, Mead, and the North Dallas side of the lake.

Tell us your busiest weekends and we'll hold the slots.

### Primary text — B (short)
Turnovers from $119 on North Dallas. Checkout to check-in in one window, staging photos every visit. Hold your summer slots before July fills.

### Primary text — C (bundle angle)
Hosting family instead of guests this summer? Book Pre-Event Prep before they arrive and the Post-Event Clean after they leave — 10% off both. About $331 for a 3 bed / 2 bath.

### Headlines (max 40 char)
- North Dallas Turnovers From $119
- Guest-Ready Between Every Stay
- Hold Your Summer Turnover Slots
- Same-Day Turnovers on the Lake

### Descriptions (max 30 char)
- Photo-verified every visit
- Kingston · Cartwright · Platter
- Flat rates, no contract

**CTA button:** Get Quote (cold) / Book Now (retarget)

---

## 2. Referral Week — `referral-a-photo`, `referral-b-editorial`
**Objective:** Leads · **Audience:** Existing customer list + 1% lookalike, 20mi around North Dallas · **Run:** one week, twice a year

### Primary text — A (community)
North Dallas runs on word of mouth. During Referral Week, send a neighbor our way and you get $25 toward your next clean — they get $25 off their first.

No cap. Five neighbors, five credits. Nothing to clip, print, or remember: the credit posts automatically after their first completed visit.

### Primary text — B (short)
$25 for you, $25 for them. Refer a neighbor during Referral Week and the credit lands on your next clean automatically.

### Primary text — C (new-customer facing)
A neighbor thinks you'd like us. Your first clean is $25 off — a Standard Clean lands at $104 for a 2 bed / 2 bath, backed by our 24-Hour Magnolia Guarantee.

### Headlines (max 40 char)
- $25 For You, $25 For Your Neighbor
- Referral Week Is Open
- Good Homes Talk To Each Other
- Refer A Neighbor, Get A Credit

### Descriptions (max 30 char)
- No limit on referrals
- Credit posts automatically
- North Dallas, TX · locally owned

**CTA button:** Learn More (cold) / Sign Up (warm)

---

## 3. Holiday Ready — `holiday-a-photo`, `holiday-b-editorial`
**Objective:** Leads · **Audience:** Homeowners 30–65, 25mi around North Dallas · **Run:** Nov 1 – Dec 23

### Primary text — A (hosting pressure)
Two cleans make the holidays: the deep one before family walks in, and the reset the morning after they leave.

Pre-holiday Deep Clean from $249. Post-event reset from $169. Book both together and save 10%.

Thanksgiving and Christmas dates go first — December fills two weeks out. Every visit is backed by our 24-Hour Magnolia Guarantee.

### Primary text — B (short)
Guests at six. Ready by four. Pre-holiday Deep Clean from $249 in North Dallas, TX — reserve your date before December fills.

### Primary text — C (the after)
The hardest clean of the year is the one after everyone leaves. Post-event reset from $169, same or next day. You handle the leftovers; we handle the rest.

### Headlines (max 40 char)
- Guests At Six. Ready By Four.
- Pre-Holiday Deep Clean From $249
- Reserve Your Holiday Date
- Book Both Cleans, Save 10%

### Descriptions (max 30 char)
- Thanksgiving & Christmas dates
- 24-Hour Magnolia Guarantee
- Same or next-day resets

**CTA button:** Book Now

---

## Compliance + QA notes
- No before/after "personal attribute" phrasing — Meta restricts implied personal characteristics.
- All prices are "from" rates for a 2 bed / 2 bath; larger homes add only for extra rooms.
- Text on image is well under 20% in every creative.
- 4:5 assets keep all copy inside the mobile safe zone; 1:1 versions are for feed and right column.
