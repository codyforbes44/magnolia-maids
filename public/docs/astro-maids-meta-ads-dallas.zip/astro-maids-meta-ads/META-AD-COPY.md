# Astro Maids — Dallas · Meta ad creatives

astromaids.com · (214) 978-6445 · hello@astromaids.com

Three campaigns (founding, referral, holiday), two concepts each (A photo, B editorial), two placements (1:1 and 4:5).
Brand: Astro Maids — Dallas. Grand opening December 1, 2026. 12+ North Dallas communities served.
Collateral pricing (biweekly, 2 bed / 2 bath): Fresh $122 · Bright $166 · Deep $280.

## Founding clients
Primary text: Luxury home cleaning arrives in North Dallas on December 1, 2026. Our first 100 founding clients keep 15% off for life. Get your quote at astromaids.com/quote.
Headlines: Founding Rates in North Dallas · 15% Off for Life · Know Your Price in a Minute

## Referral
Primary text: Great homes have great neighbors. Share Astro Maids — Dallas with the people next door and get your quote at astromaids.com/quote.
Headlines: Book With Your Neighbors · North Dallas Home Cleaning

## Holiday ready
Primary text: Opening December 1, 2026 — just in time for hosting season. Founding clients keep 15% off for life.
Headlines: Guest-Ready for the Holidays · Hosting Season, Handled

Destination: https://astromaids.com/quote (add your UTM parameters).
