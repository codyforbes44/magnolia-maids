# Astro Maids — Dallas · Social templates

Five 1080x1080 feed posts and three 1080x1920 stories.
Palette: navy #041E42, royal blue #003594, silver #869397, white. Logo: Astro star mark.
Contact on every asset: (214) 978-6445 · astromaids.com · hello@astromaids.com. QR codes open https://astromaids.com/quote (hiring QR opens /apply).

Caption starters
- Grand opening: North Dallas, Astro Maids — Dallas opens December 1, 2026. 15% off for life for our first 100 founding clients.
- Founding rates: Biweekly, 2 bed / 2 bath — Fresh $122 · Bright $166 · Deep $280.
- Hosts: Guest-ready between every stay across North Dallas.
- Hiring: Join the Astro Maids — Dallas team. Apply at astromaids.com/apply.
- Quote: Know your price before we knock — astromaids.com/quote.

Hashtags: #AstroMaidsDallas #NorthDallas #DallasHouseCleaning #ParkCities
Stories: keep stickers clear of the top and bottom 250px.
